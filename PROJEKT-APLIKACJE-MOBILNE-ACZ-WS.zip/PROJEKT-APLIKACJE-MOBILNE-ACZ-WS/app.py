from flask import Flask, render_template, request, redirect, session
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'


prace_dyplomowe = []

@app.route("/")
def index():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    login = request.form["login"]
    haslo = request.form["haslo"]
    if login == "Anna Czerniawska" and haslo == "projekt":
        return redirect("/student/Anna Czerniawska")
    elif login == "prowadzacy" and haslo == "projekt":
        return redirect("/prowadzacy")
    elif login == "Weronika Staniszewska" and haslo == "projekt":
        return redirect("/student/Weronika Staniszewska")
    else:
        return redirect("/")
    
@app.route("/logout")
def logout():
    session.pop('user', None)
    return redirect("/")

@app.route("/prowadzacy")
def prowadzacy():
    return render_template("prowadzacy.html", prace_dyplomowe=prace_dyplomowe)

@app.route("/dodaj_prace", methods=["POST"])
def dodaj_prace():
    tytul = request.form["tytul"]
    student = request.form["student"]
    wydzial = request.form["wydzial"]
    prowadzacy = request.form["prowadzacy"]
    opis = request.form["opis"]

    praca = {
        "tytul": tytul,
        "autor": student,
        "promotor": prowadzacy,
        "jednostka": wydzial,
        "opis": opis,
        "status": "oczekujaca",
        "data": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
        "plik": None,
        "recenzja": None
    }

    prace_dyplomowe.append(praca)
    return redirect("/prowadzacy")

@app.route("/student/<autor>")
def student(autor):
    moje_prace = [praca for praca in prace_dyplomowe if praca["autor"] == autor]
    return render_template("student.html", prace_dyplomowe=moje_prace)

@app.route("/upload/<int:index>", methods=["POST"])
def upload(index):
    praca = prace_dyplomowe[index]
    plik = request.files["plik"]
    plik.save(secure_filename(plik.filename))
    praca["plik"] = plik.filename
    praca["status"] = "oczekujaca"
    return redirect("/student/" + praca["autor"])

@app.route("/zatwierdz/<int:index>", methods=["GET"])
def zatwierdz(index):
    praca = prace_dyplomowe[index]
    praca["status"] = "zatwierdzona"
    return redirect("/prowadzacy")

@app.route("/odrzuc/<int:index>", methods=["GET"])
def odrzuc(index):
    praca = prace_dyplomowe[index]
    praca["status"] = "odrzucona"
    return redirect("/prowadzacy")

@app.route("/recenzja/<int:index>", methods=["POST"])
def recenzja(index):
    praca = prace_dyplomowe[index]
    recenzja = request.form["recenzja"]
    praca["recenzja"] = recenzja
    return redirect("/prowadzacy")

if __name__ == "__main__":
    app.run(debug=True)
